# ShinyMart — College Demo Store

A responsive healthcare-essentials shopping website built with HTML, CSS, and vanilla JavaScript.

## Run locally
1. Extract `ShinyMart.zip`.
2. Open the `ShinyMart` folder in VS Code.
3. Open `index.html` in a browser. Recommended: use the VS Code Live Server extension.
4. No build step, API key, server, or paid service is required for this frontend demo.

## Features
- Responsive storefront and product catalog
- Product search, category filter, and price sorting
- Add to cart, remove, quantity controls, subtotal, demo delivery, and total
- Browser-local demo registration/login
- Checkout with sample delivery address
- Simulated payment choice and order confirmation
- Demo cart/account/order data stored in browser `localStorage`

## Important limitations
This is a frontend-only college prototype. It does not include a Java backend, server-side authentication, or a database. Demo account passwords are stored in the browser and are NOT secure; use only fake credentials. Checkout does not charge money or arrange delivery. Sample products are not medical advice and this is not a real pharmacy.
