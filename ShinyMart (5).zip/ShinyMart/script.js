const products = [
  {id:1,name:"Daily Wellness Pack",category:"Wellness",price:249,emoji:"🌿",tone:"#e9f2e7",tag:"Popular",description:"A sample pack for everyday wellness routines."},
  {id:2,name:"First Aid Kit",category:"First Aid",price:349,emoji:"🩹",tone:"#f8e9df",tag:"Essentials",description:"A demo first-aid kit for minor everyday needs."},
  {id:3,name:"Digital Thermometer",category:"Equipment",price:199,emoji:"🌡️",tone:"#e5eef7",tag:"Useful",description:"A sample temperature-checking device listing."},
  {id:4,name:"Hand Sanitizer",category:"Personal Care",price:99,emoji:"🧴",tone:"#e5f2f0",tag:"Everyday",description:"A personal-care essential for your demo basket."},
  {id:5,name:"Cotton Roll",category:"First Aid",price:59,emoji:"☁️",tone:"#f3f0e7",tag:"Value",description:"Sample cotton roll product for first-aid supplies."},
  {id:6,name:"Vitamin C Sample",category:"Wellness",price:149,emoji:"🍊",tone:"#fbefda",tag:"Wellness",description:"A sample catalog item; not a medical recommendation."},
  {id:7,name:"Reusable Hot Water Bag",category:"Equipment",price:279,emoji:"♨️",tone:"#f6e5e4",tag:"Comfort",description:"A comfort product shown for demonstration purposes."},
  {id:8,name:"Gentle Skin Lotion",category:"Personal Care",price:189,emoji:"🌸",tone:"#f5e7ef",tag:"Care",description:"A sample personal-care listing for the store demo."}
];
const $ = id => document.getElementById(id);
let cart = JSON.parse(localStorage.getItem("shinyCart") || "[]");
let accountMode = "register";
let currentUser = JSON.parse(localStorage.getItem("shinyDemoUser") || "null");
let toastTimer;
const money = amount => "₹" + amount.toLocaleString("en-IN");
const saveCart = () => localStorage.setItem("shinyCart", JSON.stringify(cart));
function notify(message){$("toast").textContent=message;$("toast").classList.remove("hidden");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.add("hidden"),2400)}
function renderProducts(){
  const query=$("searchInput").value.trim().toLowerCase(), category=$("categoryFilter").value, sort=$("sortSelect").value;
  let shown=products.filter(p=>(p.name+" "+p.category+" "+p.description).toLowerCase().includes(query)&&(category==="All"||p.category===category));
  if(sort==="low")shown.sort((a,b)=>a.price-b.price);if(sort==="high")shown.sort((a,b)=>b.price-a.price);
  $("productGrid").innerHTML=shown.map(p=>`<article class="product-card"><div class="product-visual" style="--tone:${p.tone}"><span class="product-tag">${p.tag}</span><span class="product-emoji" aria-hidden="true">${p.emoji}</span></div><div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><p>${p.description}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">＋ Add to cart</button></div></div></article>`).join("");
  $("emptyState").classList.toggle("hidden",shown.length!==0);
}
function totals(){let subtotal=cart.reduce((sum,item)=>{const p=products.find(p=>p.id===item.id);return sum+(p?p.price*item.qty:0)},0);let delivery=subtotal===0?0:(subtotal>=499?0:40);return {subtotal,delivery,total:subtotal+delivery}}
function renderCart(){
  cart=cart.filter(item=>products.some(p=>p.id===item.id)&&item.qty>0);saveCart();
  $("cartCount").textContent=cart.reduce((s,i)=>s+i.qty,0);
  $("cartItems").innerHTML=cart.length?cart.map(item=>{const p=products.find(p=>p.id===item.id);return `<div class="cart-line"><div class="cart-mini" style="background:${p.tone}">${p.emoji}</div><div><h4>${p.name}</h4><small>${money(p.price)} each</small><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button><b>${item.qty}</b><button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">+</button></div></div><div><b>${money(p.price*item.qty)}</b><button class="remove-btn" data-remove="${p.id}" aria-label="Remove ${p.name}">Remove</button></div></div>`}).join(""):`<div class="empty-state">Your cart is empty.<br><br>Explore the catalog to add items.</div>`;
  const t=totals();$("subtotal").textContent=money(t.subtotal);$("delivery").textContent=money(t.delivery);$("total").textContent=money(t.total);$("checkoutTotal").textContent=money(t.total);
}
function openCart(){$("overlay").classList.remove("hidden");$("cartDrawer").classList.remove("hidden");renderCart()}
function closeLayers(){$("overlay").classList.add("hidden");$("cartDrawer").classList.add("hidden");$("accountModal").classList.add("hidden");$("checkoutModal").classList.add("hidden");$("successModal").classList.add("hidden")}
function openAccount(mode="register"){$("overlay").classList.remove("hidden");$("accountModal").classList.remove("hidden");setAccountMode(mode)}
function setAccountMode(mode){accountMode=mode;$("accountTitle").textContent=mode==="register"?"Create your demo account":"Welcome back";$("nameLabel").classList.toggle("hidden",mode==="login");$("accountName").required=mode==="register";$("accountSubmit").textContent=mode==="register"?"Create demo account →":"Login to demo account →";document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.mode===mode));$("accountPassword").autocomplete=mode==="register"?"new-password":"current-password"}
$("productGrid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const id=Number(b.dataset.add),item=cart.find(i=>i.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();renderCart();notify("Added to cart!")});
$("cartItems").addEventListener("click",e=>{const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");if(q){const item=cart.find(i=>i.id===Number(q.dataset.qty));if(item)item.qty+=Number(q.dataset.delta);cart=cart.filter(i=>i.qty>0);renderCart()}if(r){cart=cart.filter(i=>i.id!==Number(r.dataset.remove));renderCart();notify("Item removed")}});
$("searchInput").addEventListener("input",renderProducts);$("categoryFilter").addEventListener("change",renderProducts);$("sortSelect").addEventListener("change",renderProducts);
$("cartToggle").addEventListener("click",openCart);$("closeCart").addEventListener("click",closeLayers);$("overlay").addEventListener("click",closeLayers);
$("accountBtn").addEventListener("click",()=>openAccount(currentUser?"login":"register"));$("closeAccount").addEventListener("click",closeLayers);document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>setAccountMode(t.dataset.mode)));
$("accountForm").addEventListener("submit",e=>{e.preventDefault();const name=$("accountName").value.trim(),email=$("accountEmail").value.trim().toLowerCase(),password=$("accountPassword").value;if(accountMode==="register"){currentUser={name,email,password};localStorage.setItem("shinyDemoUser",JSON.stringify(currentUser));notify("Demo account created!");closeLayers()}else{const saved=JSON.parse(localStorage.getItem("shinyDemoUser")||"null");if(saved&&saved.email===email&&saved.password===password){currentUser=saved;notify("Welcome back, "+saved.name+"!");closeLayers()}else{notify("Demo account not found. Register first.");return}}$("accountBtn").textContent="Hi, "+(currentUser.name||"User").split(" ")[0]});
$("checkoutBtn").addEventListener("click",()=>{if(!cart.length){notify("Add an item before checkout.");return}closeLayers();$("overlay").classList.remove("hidden");$("checkoutModal").classList.remove("hidden");$("checkoutTotal").textContent=money(totals().total);if(currentUser)$("deliveryName").value=currentUser.name});
$("closeCheckout").addEventListener("click",closeLayers);
$("checkoutForm").addEventListener("submit",e=>{e.preventDefault();if(!cart.length){notify("Your cart is empty.");closeLayers();return}const t=totals(),orderId="SM-DEMO-"+Math.random().toString(36).slice(2,8).toUpperCase();const order={id:orderId,name:$("deliveryName").value,address:$("deliveryAddress").value,total:t.total,items:cart.map(i=>({...i})),payment:$("paymentMethod").value,date:new Date().toISOString()};let orders=JSON.parse(localStorage.getItem("shinyDemoOrders")||"[]");orders.push(order);localStorage.setItem("shinyDemoOrders",JSON.stringify(orders));cart=[];saveCart();renderCart();$("checkoutModal").classList.add("hidden");$("successModal").classList.remove("hidden");$("successMessage").textContent=`Thanks, ${order.name}. This demo order is saved only in this browser. No payment or delivery was made.`;$("orderRef").textContent=orderId});
$("closeAccount").addEventListener("click",closeLayers);$("continueShopping").addEventListener("click",()=>{closeLayers();document.querySelector("#products").scrollIntoView({behavior:"smooth"})});
$("year").textContent=new Date().getFullYear();
if(currentUser)$("accountBtn").textContent="Hi, "+currentUser.name.split(" ")[0];
renderProducts();renderCart();
