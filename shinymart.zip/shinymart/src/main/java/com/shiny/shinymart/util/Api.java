package com.shiny.shinymart.util;
import com.google.gson.Gson;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
/** Shared JSON response helper. */
public final class Api {
 private static final Gson GSON=new Gson(); private Api(){}
 public static void send(HttpServletResponse r,int status,Object data)throws IOException{r.setStatus(status);r.setContentType("application/json;charset=UTF-8");r.getWriter().write(GSON.toJson(Map.of("success",true,"data",data,"error", "")));}
 public static void error(HttpServletResponse r,int status,String code,String message)throws IOException{r.setStatus(status);r.setContentType("application/json;charset=UTF-8");r.getWriter().write(GSON.toJson(Map.of("success",false,"data", "", "error",Map.of("code",code,"message",message))));}
}