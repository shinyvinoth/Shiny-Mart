package com.shiny.shinymart.filter;
import javax.servlet.*;import javax.servlet.annotation.WebFilter;import java.io.IOException;
/** Applies UTF-8 to all requests. */
@WebFilter("/*") public class EncodingFilter implements Filter { public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{req.setCharacterEncoding("UTF-8");res.setCharacterEncoding("UTF-8");chain.doFilter(req,res);} }