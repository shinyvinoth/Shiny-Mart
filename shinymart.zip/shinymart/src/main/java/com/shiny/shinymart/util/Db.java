package com.shiny.shinymart.util;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
/** Retrieves the application-managed connection pool. */
public final class Db { private Db(){} public static Connection get(HttpServletRequest r)throws SQLException{return ((DataSource)r.getServletContext().getAttribute("dataSource")).getConnection();} }