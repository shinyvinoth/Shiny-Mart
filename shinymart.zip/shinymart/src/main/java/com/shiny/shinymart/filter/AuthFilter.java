package com.shiny.shinymart.filter;
import javax.servlet.*;import javax.servlet.annotation.WebFilter;import javax.servlet.http.*;import java.io.IOException;
/** Protects cart, order, seller and admin endpoints. */
@WebFilter("/api/v1/*") public class AuthFilter implements Filter {
 public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
  HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;String path=req.getRequestURI().substring(req.getContextPath().length());
  if(path.startsWith("/api/v1/auth/")||path.equals("/api/v1/products")||path.equals("/api/v1/health")||path.equals("/api/v1/chat")){chain.doFilter(request,response);return;}
  HttpSession session=req.getSession(false);if(session==null||session.getAttribute("userId")==null){com.shiny.shinymart.util.Api.error(res,401,"UNAUTHENTICATED","Please log in first.");return;}
  String role=(String)session.getAttribute("role");
  if((path.startsWith("/api/v1/seller/")&&! "SELLER".equals(role))||(path.startsWith("/api/v1/admin/")&&!"ADMIN".equals(role))){com.shiny.shinymart.util.Api.error(res,403,"FORBIDDEN","You do not have permission.");return;}
  chain.doFilter(request,response);
 }
}