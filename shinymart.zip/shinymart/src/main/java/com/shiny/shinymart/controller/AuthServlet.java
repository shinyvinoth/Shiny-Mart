package com.shiny.shinymart.controller;
import com.google.gson.Gson;import com.shiny.shinymart.util.*;import org.mindrot.jbcrypt.BCrypt;
import javax.servlet.annotation.WebServlet;import javax.servlet.http.*;import java.io.*;import java.sql.*;import java.util.*;
/** Handles account registration, login and logout. */
@WebServlet("/api/v1/auth/*") public class AuthServlet extends HttpServlet {
 private final Gson gson=new Gson();
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
  String action=req.getPathInfo();try{Map<?,?> body=gson.fromJson(req.getReader(),Map.class);
   if("/logout".equals(action)){HttpSession s=req.getSession(false);if(s!=null)s.invalidate();Api.send(res,200,Map.of("message","Logged out"));return;}
   String email=str(body,"email").toLowerCase(Locale.ROOT),password=str(body,"password");
   if(email.isBlank()||!email.contains("@")||password.length()<8){Api.error(res,400,"VALIDATION_ERROR","Enter a valid email and password of at least 8 characters.");return;}
   if("/register".equals(action)){String name=str(body,"name"),role=str(body,"role");if(name.isBlank()||(!"BUYER".equals(role)&&!"SELLER".equals(role))){Api.error(res,400,"VALIDATION_ERROR","Name and Buyer/Seller role are required.");return;}
    try(Connection c=Db.get(req);PreparedStatement p=c.prepareStatement("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")){p.setString(1,name);p.setString(2,email);p.setString(3,BCrypt.hashpw(password,BCrypt.gensalt(12)));p.setString(4,role);p.executeUpdate();}catch(SQLException ex){if(ex.getErrorCode()==23505){Api.error(res,409,"EMAIL_EXISTS","An account with that email already exists.");return;}throw ex;}
   } else if(!"/login".equals(action)){Api.error(res,404,"NOT_FOUND","Unknown authentication action.");return;}
   long id;String name,role;try(Connection c=Db.get(req);PreparedStatement p=c.prepareStatement("SELECT id,name,password_hash,role FROM users WHERE email=?")){p.setString(1,email);try(ResultSet r=p.executeQuery()){if(!r.next()||!BCrypt.checkpw(password,r.getString("password_hash"))){Api.error(res,401,"INVALID_CREDENTIALS","Email or password is incorrect.");return;}id=r.getLong("id");name=r.getString("name");role=r.getString("role");}}
   HttpSession old=req.getSession(false);if(old!=null)old.invalidate();HttpSession session=req.getSession(true);req.changeSessionId();session.setMaxInactiveInterval(30*60);session.setAttribute("userId",id);session.setAttribute("name",name);session.setAttribute("role",role);Api.send(res,200,Map.of("id",id,"name",name,"email",email,"role",role));
  }catch(Exception e){Api.error(res,500,"SERVER_ERROR","Unable to process authentication request.");}
 }
 private String str(Map<?,?> m,String k){Object v=m.get(k);return v==null?"":String.valueOf(v).trim();}
}