package com.shiny.shinymart;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;
import static org.junit.jupiter.api.Assertions.*;
class PasswordHashTest {
 @Test void bcryptHashVerifiesPassword() {
  String hash=BCrypt.hashpw("test-password",BCrypt.gensalt(4));
  assertTrue(BCrypt.checkpw("test-password",hash));
  assertFalse(BCrypt.checkpw("wrong-password",hash));
 }
}
