# Contributing / local workflow
1. Install JDK 17, Maven 3.9+, and Tomcat 9.
2. Clone the repository and open it as a Maven project.
3. Run `mvn clean verify`.
4. Deploy `target/shinymart.war` to Tomcat 9 and test `/shinymart/`.
5. Use small feature branches and conventional commits (`feat:`, `fix:`, `test:`, `docs:`).
6. Never commit passwords, API keys, database files, or `.env`.
