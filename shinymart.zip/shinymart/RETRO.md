# Sprint retrospective
- What worked: core requirements were collected into a single runnable Maven project.
- What didn't: deployment and full end-to-end verification still require a local Tomcat 9 environment.
- Next change: run the build, test each role, and improve coverage before public deployment.
