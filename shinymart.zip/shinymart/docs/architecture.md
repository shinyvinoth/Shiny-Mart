# ShinyMart architecture
Browser (JSP + CSS + vanilla JS fetch) → UTF-8 filter / authorization filter → Servlet endpoints → JDBC prepared statements → HikariCP → H2.

## Main layers
- `controller`: HTTP orchestration and request validation.
- `util`: API response envelope and DataSource access.
- `listener`: owns connection-pool lifecycle and database bootstrap.
- `filter`: encoding and protected-route checks.
- `model/service/dao`: planned expansion points for the stricter layered MVC architecture; core starter servlet methods currently contain the JDBC operations and should be separated into DAO and service classes for a rubric that requires strict SOLID layering.

## ER overview
- users 1—many products
- users 1—many orders
- orders 1—many order_items
- products 1—many order_items
- users 1—many cart_items; products 1—many cart_items
- users 1—many reviews; products 1—many reviews

## Place-order sequence
Browser → OrderServlet → H2 via JDBC: validate cart/stock, insert order, insert order items, decrement stock, clear cart, commit → JSON response.
