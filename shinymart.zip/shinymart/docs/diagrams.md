# Required design diagrams

## D1 — ER diagram
```mermaid
erDiagram
  USERS ||--o{ PRODUCTS : lists
  USERS ||--o{ ORDERS : places
  ORDERS ||--|{ ORDER_ITEMS : contains
  PRODUCTS ||--o{ ORDER_ITEMS : included_in
  USERS ||--o{ CART_ITEMS : owns
  PRODUCTS ||--o{ CART_ITEMS : added_to
  USERS ||--o{ REVIEWS : writes
  PRODUCTS ||--o{ REVIEWS : receives
  USERS { bigint id PK string name string email UK string password_hash string role timestamp created_at }
  PRODUCTS { bigint id PK bigint seller_id FK string name decimal price int stock_qty string category timestamp created_at }
  ORDERS { bigint id PK bigint buyer_id FK string status decimal total_amount timestamp created_at }
  ORDER_ITEMS { bigint id PK bigint order_id FK bigint product_id FK int quantity decimal unit_price timestamp created_at }
  CART_ITEMS { bigint id PK bigint user_id FK bigint product_id FK int quantity timestamp created_at }
  REVIEWS { bigint id PK bigint product_id FK bigint user_id FK int rating string comment timestamp created_at }
```

## D2 — Use case diagram
```mermaid
flowchart LR
  Buyer([Buyer]) --> Browse[Browse/search products]
  Buyer --> Cart[Manage cart]
  Buyer --> Checkout[Mock checkout]
  Buyer --> History[View order history]
  Buyer --> Review[Review purchased product]
  Seller([Seller]) --> Listing[Create/edit/delete listings]
  Seller --> Incoming[View incoming orders]
  Admin([Admin]) --> Users[View users]
  Admin --> Orders[View all orders]
  Admin --> Moderate[Remove listings]
```

## D3 — Place-order sequence
```mermaid
sequenceDiagram
  actor Browser
  participant Servlet as OrderServlet
  participant DB as H2 Database
  Browser->>Servlet: POST /api/v1/orders/checkout
  Servlet->>DB: Read cart and lock stock rows
  DB-->>Servlet: Cart rows and stock quantities
  Servlet->>DB: Insert order and order_items
  Servlet->>DB: Decrement stock and clear cart
  Servlet->>DB: COMMIT
  Servlet-->>Browser: 201 JSON order confirmation
```
