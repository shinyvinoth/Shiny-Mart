# ShinyMart

ShinyMart is a college-project marketplace starter built with Java 17, Maven, Servlet API (`javax.servlet`, Tomcat 9), JSP, JDBC/H2, HikariCP and jBCrypt. It follows the uploaded project specification: buyer/seller roles, product listings, cart, mock checkout, orders, admin moderation, reviews and a product FAQ chatbot.

## Requirements
- JDK 17
- Maven 3.9+
- Apache Tomcat 9.0.x

## Run locally
1. Open this folder in VS Code or IntelliJ.
2. Run `mvn clean package`.
3. Copy `target/shinymart.war` to Tomcat 9's `webapps/`.
4. Start Tomcat and visit `http://localhost:8080/shinymart/`.
5. The database file is created under the app's working directory as `./data/shinymart`.

For easiest local development, you can also import as a Maven project. The app creates tables and demo products at startup.

## Demo accounts
- Admin: `admin@shinymart.local` / `Admin@12345`
- Seller: `seller@shinymart.local` / `Seller@12345`
- Buyer: `buyer@shinymart.local` / `Buyer@12345`

Change demo passwords before any public deployment. This is a learning/demo project, not a production pharmacy or medical advice service. It does not process real payments or sell prescription medicines.

## Features
- Registration and login (BUYER/SELLER); seeded ADMIN account
- Browse/search/filter product catalog
- Seller product create/edit/delete
- Buyer cart and mock checkout
- Buyer order history; seller order view
- Admin user/order overview and listing moderation
- Ratings and reviews for purchased products
- FAQ chatbot (`mock` provider, no API key needed)
- JSON endpoints under `/api/v1/`
- Parameterized JDBC statements, bcrypt password hashing, session timeout, auth checks
- GitHub Actions Maven build workflow

## Main endpoints
- `GET /api/v1/products?q=&category=`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `POST /api/v1/auth/logout`
- `GET /api/v1/cart`
- `POST /api/v1/cart` with `productId`, `quantity`
- `DELETE /api/v1/cart?productId=`
- `POST /api/v1/orders/checkout`
- `GET /api/v1/orders`
- `GET /api/v1/seller/orders`
- `GET /api/v1/admin/summary`
- `POST /api/v1/reviews`
- `POST /api/v1/chat`
- `GET /api/v1/health`

## Important
- Checkout is a mock confirmation, not a real payment.
- For public deployment, configure persistent H2 storage and HTTPS, rotate demo credentials, add CSRF protection, and configure the database path/environment secrets.
- Verify with `mvn clean verify` and a real Tomcat 9 deployment before submitting.
