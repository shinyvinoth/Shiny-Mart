# Changelog
## 1.0.0
- Initial ShinyMart student marketplace project scaffold with catalog, auth, cart, mock checkout, orders, admin summary, reviews and FAQ assistant.
